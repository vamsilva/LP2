﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482013043
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double TotalSemana;
            double TotalMes1=0, TotalMes2=0, TotalMes3=0;
            double TotalGeral=0;
            int Semana, Mes;
            int Matriz[10][10];
            string Aux = "";


            for (Mes = 0; Mes < 3; Mes++)
            {
                for (Semana = 0; Semana < 4; Semana++)
                {
                    Aux = Interaction.InputBox("Digite o valor de vendas da " + (Semana + 1).ToString() + " ª semana do mês " + (Mes + 1).ToString() + "é: ");

                    if (Aux != "")
                    {
                        TotalGeral += Matriz[Mes][Semana];
                        TotalSemana = Matriz[Mes][Semana];
                        lstTabela.Items.Add("Total do mês" + (Mes + 1) + "; Semana" + (Semana + 1) + ": R$" + TotalSemana);
                    }
                    else
                    {
                        MessageBox.Show("Preencha as informações!");
                    }

                    TotalMes1 = Matriz[0][0] + Matriz[0][1] + Matriz[0][2] + Matriz[0][3];
                    TotalMes2 = Matriz[1][0] + Matriz[1][1] + Matriz[1][2] + Matriz[1][3];
                    TotalMes3 = Matriz[2][0] + Matriz[2][1] + Matriz[2][2] + Matriz[2][3];

                }
            }

            lstTabela.Items.Add("Total do Mês 1: " + TotalMes1.ToString(
        }
    }
}
